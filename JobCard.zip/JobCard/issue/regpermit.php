<?php 
	//create array of requests 
	$arrRequests = array("1"=>"Request to register a heritage site","2"=>"Request to register a heritage object",
	"3"=>"Request to develop a site","4"=>"Request for exemption to develop a site","5"=>"Request for permit to loan an object",
	"6"=>"Request for import / Export of object","7" => "Request for exemption to conduct heritage impact assessment");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!-- Viewport Meta Tag -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
      Permit Application - Limpopo eHeritage
    </title>
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
    <!-- Main Style -->
    <link rel="stylesheet" type="text/css" href="../assets/css/main.css">
    <!-- Slicknav Css -->
    <link rel="stylesheet" type="text/css" href="../assets/css/slicknav.css">

    <!-- Responsive Style -->
    <link rel="stylesheet" type="text/css" href="../assets/css/responsive.css">
    <!--Fonts-->
    <link rel="stylesheet" media="screen" href="../assets/fonts/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" media="screen" href="../assets/fonts/simple-line-icons.css">    
     
    <!-- Extras -->
    <link rel="stylesheet" type="text/css" href="../assets/extras/owl/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="../assets/extras/owl/owl.theme.css">
    <link rel="stylesheet" type="text/css" href="../assets/extras/animate.css">
    <link rel="stylesheet" type="text/css" href="../assets/extras/normalize.css">
    

    <!-- Color CSS Styles  -->  
    <link rel="stylesheet" type="text/css" href="../assets/css/colors/green.css" media="screen" /> 
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js">
    </script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js">
    </script>
    <![endif]-->
	<style>
		.caps
		{
			text-transform:uppercase;
		}
		.apply_request
		{
			display:none;
		}
		.error
		{
			color:#f00;
		}
		/*#overlay {
			background-color: rgba(0, 0, 0, 0.8);
			z-index: 999;
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			display: none;
		}*/
.stepwizard-step p {
    margin-top: 10px;
	color:#FFF;
}

.stepwizard-row {
    display: table-row;
}

.stepwizard {
    display: table;
    width: 100%;
    position: relative;
}

.stepwizard-step button[disabled] {
    opacity: 1 !important;
    filter: alpha(opacity=100) !important;
}

.stepwizard-row:before {
    top: 14px;
    bottom: 0;
    position: absolute;
    content: " ";
    width: 100%;
    height: 1px;
    background-color: #ccc;
    z-order: 0;

}

.stepwizard-step {
    display: table-cell;
    text-align: center;
    position: relative;
}

.btn-circle {
  width: 30px;
  height: 30px;
  text-align: center;
  padding: 6px 0;
  font-size: 12px;
  line-height: 1.428571429;
  border-radius: 15px;

} 
.paddingtop_style{ padding-top:39px;}	
textarea:disabled, input:disabled, select:disabled  {
    background: #FFF !important;
}
		
	</style>
  </head>
  <body class="bg-dark">
	
    <!-- Header area wrapper starts -->
	<?php include("portal_header.php"); ?>
    <!-- Header-wrap Section End -->
    <!-- Page Header -->
    <div class="page-header-section">
      <div class="container">
        <div class="row">
          <div class="page-header-area">
            <div class="page-header-content">
              <h2 class="reqheading">Apply for Permit</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page Header End -->

    <section class="contact2-section section">
	<?php
	if(!isset($_GET['request']) && !isset($_GET['p_id']))	
	{
		?>
      <div class="container">
        <div class="row justify-content-center">
			<div class="col-md-12 choose_request">
              <h3 class="small-title mb-3"><i class="fa fa-cloud-download icon-round-border icon-md"></i>CHOOSE YOUR REQUEST</h3>
              <!-- Block level buttons -->
              <div class="row block-level-buttons clearfix">
				
					<?php 
					foreach($arrRequests as $key => $value)
					{
						$col = 6;
						if($key == 7)
							$col = 12;
						echo '<div class="col-md-'.$col.'"><div class="form-group">
						  <a href="javascript:;" id="'.$key.'" style="text-transform:capitalize;" onclick="chooseReq(this.id,\''.$value.'\')" class="btn btn-common btn-lg btn-block caps" >'.$value.'</a>
						</div></div>';
					}					
					?>					
					
              </div>				
			</div>
        </div>
      </div>
			<?php
			}	
			else
			{
			?>	  
    <div class="container">
<div class="stepwizard">
    <div class="stepwizard-row setup-panel">
        <div class="stepwizard-step">
            <a href="#step-1" type="button" class="btn btn-warning btn-circle">1</a>
            <p>Applicant Details</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-2" type="button" class="btn btn-info btn-circle disabled" >2</a>
            <p>Application Details</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-3" type="button" class="btn btn-info btn-circle disabled">3</a>
            <p>Attach Supporting Documents</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-4" type="button" class="btn btn-info btn-circle disabled">4</a>
            <p>Finalise & Submit</p>
        </div>		
    </div>
</div>
    <div class="row setup-content justify-content-center" id="step-1">
        <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header bg-warning">
                            APPLICANT DETAILS 
							<button onclick="enableElements()" style="display:none" class="btn btn-sm btn-warning pull-right editApp"><i class="fa fa-pencil"></i></button>
							<a href="javascript:;" style="display:none" onclick="document.getElementById('btnUpdateUser').click()" style="display:none" class="btn btn-warning pull-right saveApp"><i class="fa fa-save"></i></a>
						</div>  
                        <div class="card-body">	  
 
 				<form method="post" role="form" class="mt-30 shake" id="frmUpdateUser" name="frmUpdateUser" data-toggle="validator">
					<div class="row"> 
						<div class="col-md-6">
							<div class="form-group">
							  <div class="form-line">
								<input type="text" class="form-control profile_name" name="fnames">
							  </div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
							  <div class="form-line">
								<input type="text" placeholder="Surname" class="form-control surname" name="surname" required>
							  </div>
							</div>						
						</div>
					</div>
             
					<input type="hidden" class="form-control userid" name="userid">

                <div class="form-group">
				  <div class="form-line">
					<input type="text" class="form-control profile_email" disabled>
                  </div>
                </div>
				<div class="row">
				<div class="col-md-6">
					<div class="form-group">
					  <label for="message" class="sr-only">Postal Address</label>
					  <div class="form-line">
						<textarea rows="4" placeholder="Postal Address" class="form-control postal" name="postal" required></textarea>
					  </div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
					  <label for="message" class="sr-only">Residential Address</label>
					  <div class="form-line">
						<textarea rows="4" placeholder="Residential Address" class="form-control res" name="res" required ></textarea>
					  </div>
					</div>
				</div>
				</div>
                <div class="form-group">
                  <label for="message" class="sr-only">Name of Institution</label>
				  <div class="form-line">
					<input type="text" placeholder="Name of Institution" class="form-control institution" name="institution" required>
                  </div>
                </div>
           			  
                <div class="form-group">
                  <label for="message" class="sr-only">ID Number</label>
				  <div class="form-line">
					<input type="text" placeholder="ID Number" class="form-control idnum" name="idnum" required>
                  </div>
                </div>
            	

                <div class="form-group">
                  <label for="message" class="sr-only">Motivation, Why applying the site?</label>
				  <div class="form-line">
					<input type="text" class="form-control profile_cell" disabled>
                  </div>
                </div>
             			

				<button type="submit" id="btnUpdateUser" class="btn btn-primary nextBtn btn-lg pull-right btnUpdateUser">Next</button>
				</form>
			</div>
			</div>
        </div>
    </div>
    <div class="row setup-content justify-content-center" id="step-2">
        <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header bg-warning">
                            APPLICATION DETAILS 
							<button onclick="enableElements()" style="display:none" class="btn btn-sm btn-warning pull-right editApp"><i class="fa fa-pencil"></i></button>
							<a href="javascript:;" onclick="document.getElementById('btnSubPermit').click()" style="display:none" class="btn btn-warning pull-right saveApp"><i class="fa fa-save"></i></a>
                        </div>
                        <div class="card-body">				
			<form method="post" role="form" class="mt-30 shake" id="frmSubPermit" name="frmSubPermit" data-toggle="validator">			
				<div class="form-group">
					<label for="request" class="sr-only">request</label>
					<select class="form-control selreq" name="selreq">
						<?php 
						foreach($arrRequests as $key => $value)
						{
							echo '<option onclick="chooseReq(\''.$key.'\',\''.$value.'\')" value="'.$key.'">'.$value.'</option>';
						}
						?>
					</select>	
				</div>
				
				<input type="hidden" class="form-control pid" name="pid" >
				
				<div class="form-group">
					<input type="text" placeholder="" class="form-control proposedName" name="proposedName" required>			
				</div>
				<div class="form-group">
					<textarea placeholder="" rows="4" class="form-control apply_motivation" name="apply_motivation" required data-error="Write your message"></textarea>
                </div>	
				<div class="row">	
					<div class="col-md-12" style="display:none">	
						<div class="form-group">
							<label for="state" class="sr-only">Province:</label>	
							  <div class="form-line">
									<select class="form-control contact-control" id="state" name="state" data-error="Please Select Province">
									  <option selected="selected" value="" >--Select Province--</option>
									  <option value="1"> Eastern Cape</option>
									  <option value="2"> Free State</option>
									  <option value="3"> Gauteng</option>
									  <option value="4"> KwaZulu-Natal</option>
									  <option value="5"> Limpopo</option>   
									  <option value="6"> Mpumalanga</option>
									  <option value="7"> Northern Cape</option>
									  <option value="8"> North West</option>
									  <option value="9"> Western Cape</option>                                                  
									</select>
									<div class="help-block with-errors"></div>
							  </div>
						</div>				
					</div>
					<div class="col-md-6">	
						<div class="form-group">
							<label for="district" class="sr-only">District:</label>
							<div class="district form-line">
								<select name="district" class="form-control contact-control" required >
									<option selected="selected" value="">--Select District--</option>
								</select>				  
							</div>
						</div>					
					</div> 
					<div class="col-md-6">	
						<div class="form-group">
							<label for="area" class="sr-only">Municipal Area:</label>
							<div class="area form-line">
								<select name="area" class="form-control contact-control" required >
									<option selected="selected" value="">--Select Municipal Area--</option>
								</select>				  
							</div>
						</div>					
					</div> 
				
					<div class="col-md-6">	
					  <div class="form-group">
						<label for="personApplying" class="sr-only">Contact Person Applying</label>
						<div class="form-line">
							<input type="text" placeholder="Contact Person Applying" class="form-control personApplying" name="personApplying" required >
						</div>
					  </div>
					</div>
					<div class="col-md-6">	
					  <div class="form-group">
						<label for="subject" class="sr-only">Contact Number</label>
						<div class="area form-line">
							<input type="text" placeholder="Contact Number" class="form-control contactNum" name="contactNum" required >
						</div>
					  </div>
					</div>
				</div>	
                  <div class="form-group">
                    <label for="subject" class="sr-only">Website if Available</label>
					<div class="area form-line">
						<input type="text" placeholder="Website if Available" class="form-control website" name="website" required >
                    </div>
                  </div>
				<button type="submit" id="btnSubPermit" class="btn btn-primary nextBtn btn-lg pull-right btnSubPermit">Next</button>
				</form>
			</div>
		</div>		
        </div>
    </div>
    <div class="row setup-content justify-content-center" id="step-3">
        <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header bg-warning">
                            ATTACH SUPPORTING DOCUMENTS
                        </div>
                        <div class="card-body">				
				<form method="post" class="mt-30 shake" id="sendResponse" name="sendResponse" >			
			  <div style="display:none" id="addinput">
			  
			  </div>	
			  <input id="numfiles" type="hidden" name="numfiles" />
              
			  	<input type="hidden" placeholder="" class="form-control pid" name="pid" >
				
				<div class="form-group pnlAddfile">
					<label>Other Supporting Documents:</label>
					<br>
					<button type="button" class="btn btn-success addfile"><i class="fa fa-plus"></i> Add File</button>
				</div>			  

				<button id="btnSendResponse" type="submit" class="btn btn-primary btn-lg pull-right btnSendResponse">Next</button>	
				<button style="display:none" id="saveAtt" class="btn btn-primary nextBtn"></button>	
				</form>					
                <!--button class="btn btn-success btn-lg pull-right" type="submit">Finish!</button-->
			</div>
		</div>		
        </div>
    </div>
    <div class="row setup-content justify-content-center" id="step-4">
        <div class="col-lg-8">
			  <div class="col-md-12">
                    <div class="card wizzard_final">
                        <div class="card-header bg-warning">
                                Finalise & Submit - ACCEPT TERMS OF USE 
                        </div>
                        <div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<iframe style="width:100%" frameborder="0" src="http://dev.limeheritage.co.za/admin/Lihra%20Certification%20Design.pdf"></iframe>
									</div>
									<form method="post" role="form" class="mt-30 shake" id="finishfrm" name="finishfrm" data-toggle="validator">
									<div class="form-group">
										<div class="form-check">
											<input type="checkbox" required name="terms" class="form-check-input" id="materialUnchecked">
											<label class="form-check-label" for="materialUnchecked">
												<strong>By Ticking you accept above terms of use and policy of Lihra</strong>
											</label>
										</div>
									</div>								
									<div class="form-group">
										<label>Signature</label>
										<div class='js-signature'></div>
										<div class='sig'></div>
										<input type="hidden" placeholder="" class="form-control pid" name="pid" >
										<input type="text" name="signature" class="form-control signature">
									
										<button type="button" class="btn btn-danger clearSignature">clear</button>
									</div>
									<div class="form-group">
									  <button class="btn btn-warning btn-lg pull-right btnfinish" type="submit"><i class="fa fa-share"></i> SUBMIT</button>
									</div>
									</form>									
								</div>
							</div>	
						</div> 
					</div>	
	
                    <div class="card wizzard_success" style="display:none">
                        <div class="card-header bg-warning">
                            SUCCESS, APPLICATION IS SUCCESSFULLY LAUNCHED 
                        </div>
                        <div class="card-body">
							<div class="form-group">
							<p align="center">Thank you for Applying, your Application is Saved and Launched
							Successfully If you feel editing your application , please do so for only
							given two days, after two days you wont be able to
							edit your application, because it will be processed</p>
							</div>
							<a href="accounts.php" class="btn btn-link btn-lg pull-right">&larr; back to portal account</a>
						</div>
					</div>	
	
			  </div>
								
		</div>
	</div>	
</div>	
<?php
			}
?>	  
    </section>

    <!-- Footer Section -->
	<?php include("../client/footer.php");?>
    <!-- Footer Section End-->
    
    <!-- Go To Top Link -->
    <a href="#" class="back-to-top">
      <i class="fa fa-angle-up">
      </i>
    </a>
    
    <!-- JavaScript & jQuery Plugins -->
    <script src="../assets/js/jquery-2.0.0.js"></script>
	<script src="../assets/js/base64.js"></script> 
	<script src="../assets/js/eherit_session.js"></script> 
	<script src="../assets/js/eheritage.js"></script> 
	<script src="../assets/js/ajax_register.js"></script> 
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.mixitup.js"></script>
    <script src="../assets/js/smoothscroll.js"></script>
    <script src="../assets/js/wow.js"></script>
    <script src="../assets/js/owl.carousel.js"></script> 
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/jquery.counterup.min.js"></script>
    <script src="../assets/js/jquery.slicknav.js"></script>
    <script src="../assets/js/jquery.appear.js"></script>
    <script src="../admin/plugins/jquery-validation/jquery.validate.js"></script>
    <script src="../assets/js/main.js"></script> 
	<script src="../admin/js/pages/examples/sign-up.js"></script>
	<script src="../assets/js/upload_input.js"></script>
	<script src="../assets/js/jq-signature.min.js"></script>	
	<script src="../assets/js/jquery-migrate-1.1.1.js"></script>
<script type="text/javascript">
	

    var navListItems = $('div.setup-panel div a'),
            allWells = $('.setup-content'),
            allNextBtn = $('.nextBtn');

    allWells.hide();

    navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),//#step-2
                $item = $(this);
		
        if (!$item.hasClass('disabled')) {
            navListItems.removeClass('btn-warning').addClass('btn-info');
            $item.addClass('btn-warning');
            allWells.hide();
            $target.show();
            $target.find('input:eq(0)').focus();
        }
    });

    allNextBtn.click(function(){
        var curStep = $(this).closest(".setup-content"),
            curStepBtn = curStep.attr("id"),
            nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
            curInputs = curStep.find("input[type='text'],input[type='url']"),
            isValid = true;

        $(".form-group").removeClass("has-error");
        for(var i=0; i<curInputs.length; i++){
            if (!curInputs[i].validity.valid){
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid)
            nextStepWizard.removeClass('disabled').trigger('click');
    });

    $('div.setup-panel div a.btn-warning').trigger('click');
	</script>	
    <script>
	$("select[name='state']").prop("selectedIndex", 0);
	function chooseReq(req,value)
	{
		location.href = "?request="+Base64.encode(req)+"-"+Base64.encode(value);
	}
	function userdetails(req_id)
	{
		var proposed;
		var motivation;
		
		if (req_id == 1 || req_id == 3 || req_id == 4 || req_id == 7) {
			proposed = "Name of proposed Heritage Site";
			motivation = "Motivation Why applying the site";
		}	
		else if (req_id == 2 || req_id == 5) {
			proposed = "Name of proposed Heritage Object";
			motivation = "Motivation Why applying the Object";
		}	
		else if (req_id == 6) {
			proposed = "Name of Object to be Exported";
			motivation = "Motivation applying Import/Export of an object";
		}			
		$(".proposedName").attr("placeholder", proposed);
		$(".apply_motivation").attr("placeholder", motivation);		
		
		
		$('.selreq').val(req_id);
		var user = getJson(BaseUrl+"/userbyid/"+$('.btn_profile').attr('id'));	
		$('.userid').val($('.btn_profile').attr('id'));
		$('.profile_name').val(user.names)
		$('.profile_email').val(user.email)
		$('.profile_cell').val(user.cell)
		$('.surname').val(user.surname)
		$('.postal').val(user.postal)
		$('.res').val(user.res)
		$('.institution').val(user.institution)
		$('.idnum').val(user.idnum)
	}
		
    if(getUrlVars()["request"]) 
	{
		var req_id = Base64.decode(getUrlVars()["request"].split('-')[0]);	
		var req = Base64.decode(getUrlVars()["request"].split('-')[1]);
		$('.reqheading').html(req);
		
		$.get(BaseUrl+"/loadFormsByRequest/"+req_id,function(response){
			var data = $.parseJSON(response);			
			$.each(data, function (index, frm) {	
				forfiles(index,'',frm.frm_description,'edit') 
			});
		});	
		
		$(window).load(function() {
			userdetails(req_id);
		});	  
	}

    else if(getUrlVars()["p_id"]) 
	{	
		
		$('#overlay').show()
		$(window).load(function() {
			
			$('.pid').val(Base64.decode(getUrlVars()["p_id"]))
			
			
			$.get(BaseUrl+'/permitbyid/'+Base64.decode(getUrlVars()["p_id"]),function(response){
				//alert(response) 
				var p = $.parseJSON(response);  
				userdetails(p.reqid);
				$(".proposedName").val(p.proposedName);
				$(".apply_motivation").val(p.motivation);
				disableElements(p.accepted)	
				areaLocation(p.state_id,p.district_id,p.area)
				
				$(".personApplying").val(p.personApplying);
				$(".contactNum").val(p.contactNum);		
				$(".website").val(p.website);	
				var edit = 'edit';
					if(p.accepted > 0)
						edit = '';
				$.each(p.files, function (index, frm) {	
					forfiles(index,frm.file,frm.desc,edit) 
				});	
				
				$.each(p.otherdesc, function (index, frm) {	 
					forfiles(index,'',frm,edit) 
				});	
				if(p.signature)
				{
					$('.sig').html('<img src="'+Base64.decode(p.signature)+'">')
					$('.js-signature').hide();
					$('.signature').val(p.signature)
				}				
				$('#materialUnchecked').prop('checked', false);
				if(p.terms > 0)
					$('#materialUnchecked').prop('checked', true);
			});					
			
			
			navListItems.removeClass('disabled')
			$('.reqheading').html($('.selreq option:selected').text());
		});
	}


	//signature
	$('.js-signature').jqSignature();
	$('.clearSignature').click(function(){
		$('.js-signature').show().jqSignature('clearCanvas');
		$('.sig').hide()
		$('.signature').val('')
	});
	var enableSave = false;
	$('.js-signature').on('jq.signature.changed', function() {
		$('.saveSignature').attr('disabled', false);
		enableSave = true;
	});	
			
	$( ".js-signature" ).mouseleave(function() {
		if(enableSave === true)
		{
			$('.signature').val(Base64.encode($('.js-signature').jqSignature('getDataURL')));
			enableSave = false;
			$('.saveSignature').attr('disabled', true);
		}
	});				
	</script>	 
  </body>
</html>