<?php
include('connection.php');
include('session.php');
//include('data.php');

if(empty($_SESSION['name'])){
    header('location: login.php');
}
   
	
	//print_r($_POST);
	$user_id = $_POST['user_id'];
	$assets = $_POST['assets'];
	$asset = $_POST['assets'];
	$description = $_POST['description'];
	$locations = $_POST['locations'];
	$Severity = $_POST['severity'];
	$esd = $_POST['esd'];
	$bimage = $_POST['bimage'];
	//$assignedTo = $_POST['assignedTo'];
	
	date_default_timezone_set('Africa/Johannesburg');
	$issueDate = date("Y/m/d");
	$issueTime = date("h:i:sa");
	
	//$image = $_FILES['image']['tmp_name'];
	
	try{
		
		$sql = "INSERT INTO job(user_id, asset, ESD, description, location, 
			severity, issueDate, issueTime)
			VALUES ('$user_id', '$asset', '$esd', '$description', '$locations', '$Severity', '$issueDate', '$issueTime')"; 
		$sth = $conn->query($sql);
		
		$job_id = $conn->lastInsertId();
	
	
		$sql2 = "INSERT INTO status(job_id, status, comments, dater, timer)
				VALUES('$job_id', 'Opened', '$description', '$issueDate', '$issueTime')";
				
		$sth = $conn->query($sql2);
		
		
		if($sth)
		{
				//Image Upload
			//$bname = $_POST['bname'];
			$bimage = $_FILES['name']['bimage'];

			$sql3 = "INSERT INTO uploads (issue_id, image) 
					 VALUES ('$job_id','$bimage')";
					 
				if($conn->query($sql3))
				{
					$lastid = $conn->lastInsertId();
					move_uploaded_file($_FILES['bimage']['tmp_name'], "uploads/".$lastid.'-'.'('.$job_id.')'.$bimage);
					//header('Location: issuelog.php?id='.$id.'&msg=');
				}
				echo "Success";
		}
		
			
			else{
				echo "Problems with uploading the image, contact the Developer";
			}
	}
	
	catch(PDOException $e){
		echo $e;	
	}
	
 
	
	
	
	
	
	
	
	
	
	
	
	
	
?>