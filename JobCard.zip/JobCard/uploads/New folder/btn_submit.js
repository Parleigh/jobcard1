$(document).ready(function(){
	
	$("#btn_addJob").click(function(){
		var fd = new FormData();
		var files = document.getElementById("bimage").files[0];
		var bimage = $('#bimage').val();
		fd.append('file',files);
		alert(files);
		alert(bimage);
		alert(fd);
		
		
		
		var user_id = $('#user_id').val();
		var assets = $('#assets').val();
		var esd = $('#esd').val();
		var description = $('#description').val();
		var stat = $('#stat').val();
		var bimage = $('#bimage').val();
		var locations = $('#locations').val();
		var severity = $('#severity').val();
		fd.append('user_id',user_id);
		
		$.ajax({
			url:"addJobProcess.php",
			type:"post",
			data:{user_id:user_id,
				  assets:assets,
				  esd:esd,
				  description:description,
				  stat:stat,
				  bimage:fd,
				  locations:locations,
				  severity: severity,
				  },
			success:function(response)
			{
				console.log(response);
				alert("Successfully Added Job");
				
					
					$("#issueInputForm")[0].reset()
					
				
				
			}
		});
		
		
	});
});


//Delete














