<?php 
include('connection.php');
include('session.php');
include('data.php');

if(empty($_SESSION['name'])){
    header('location: login.html');
}
    

    //$userDetails=$userClass->userDetails($session_id);
?>

<!DOCTYPE html>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>Job Card</title>
        <!--compiled and miniied CSS-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        
        <link rel="stylesheet" href=" https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
        
        
    </head>
    <body>  
        <div class="container">
            <h1>Moepathutsi <small>Job Card</small></h1>
            
			
            WELCOME: <?php echo $_SESSION['name'] ?>
			<!--?php echo $_SESSION['phone']?-->
            <a href="login.html">Logout</a>
            
            <div class="jumbotron">
            <h3>Add New Job</h3>
                
            <form id="issueInputForm">

                <div class="form-group">
                    <label>Asset Type</label>
                    <input type="text" class="form-control" id="assets" placeholder="Asset with Issue">
                </div>               
                
                <div class="form-group">
                    <label>Issue Description</label>
                    <textarea type="text" class="form-control" id="description" placeholder="Issue Description"></textarea>
                </div>
                
                
                <div class="form-group">
                    <label for="issueSeverityInput">Severity</label>
                    <select id="severity" class="form-control">
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                    </select>
                </div>                
                
                <div class="form-group">
                    <label for="issueSeverityInput">Issue Assigned To</label>
                    <select id="assignedTo" class="form-control">
                        <option value="Ezra">Ezra</option>
                        <option value="Tshepo">Tshepo</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Add Issue</button>
            </form>
            </div>
            
            <div class="col-lg-12">
			
			
                <div id="issuesList">
					<table id="tableList" class="table table-bordered">
						<thead>
							<tr>
								<th>Name</th>
								<th>Branch</th>
								<th>Division</th>
								<th>Office Number</th>
							</tr>
						</thead>
						
						<tbody>
						
						</tbody>
					</table>
                
                </div>
            </div>
            
            <div class="footer">
            <p><center>Moepathutsi Consulting &copy;</center></p>
            </div>
            
        </div>
        
        
        <!--compiled and miniied JavaScript-->
        <script src="https://chancejs.com/chance.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="crossorigin="anonymous"></script>
        <!--compiled and miniied JavaScript-->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
       <script src="main.js"></script> 
        
        <script src"https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src"https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src"https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
        
        <script>
        $(document).ready(function() {
        $('#example').DataTable();
        } );
        </script>
        

    </body>
    
</HTML>
