<?php
include("session.php");

//Getting data from database
$con = mysqli_connect("localhost", "root", "", "jobcard_db1");

//getting data from users table
$result = mysqli_query($con, "SELECT name, surname, phone, branch, division, offNo, email, password, userType, active FROM users");

//storing an aaray
$USE = array('name'=>$_SESSION['name'], 'surname'=>$_SESSION['surname'], 'phone'=>$_SESSION['phone'], 'branch'=>$_SESSION['branch'],
			'division'=>$_SESSION['division'],'offNo'=>$_SESSION['offNo'], 'email'=>$_SESSION['email'], 'password'=>$_SESSION['password'],
				'userType'=>$_SESSION['userType'], 'active'=>$_SESSION['active'],);
/*
$data = array();
while ($row = mysqli_fetch_assoc($result)){
    $data[] = $row;
}*/

echo json_encode($USE);

?>