
 <link rel="stylesheet" type="text/css" href="css/chat.css">
<?php
	
	$conn = mysqli_connect("localhost","root","","jobcard_db");
	
	$user = "SELECT * FROM users";
	$r_user = mysqli_query($conn, $user);
	
	while($row = mysqli_fetch_array($r_user)){
		$user_id = $row['id'];
		$user_name = $row['name'];
		$login = $row['log_in'];
		
		echo 
			"<li>
				<div >
				<p><a href='chat_final.php?name = $user_name'>$user_name </a></p>";
			
			if($login == "Online"){
				echo 
				"<span><i class='fa fa-circle' aria-hidden='true'></i>Online</span>";
			}
			else{
				"<span><i class='fa fa-circle-o' aria-hidden='true'></i>Offline</span>";
			}
			"
				</div>
			</li>
			";
	}
			
			
	

?>