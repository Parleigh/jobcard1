
<?php 
include('connection.php');
session_start();
//include('data.php');



?>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Jobcard</title>
</head>

<style>

body{
    margin: 0;
    font-size: .9rem;
    font-weight: 400;
    line-height: 1.6;
    color: #212529;
    text-align: left;
    background-color: #f5f8fa;
}

.navbar-laravel
{
    box-shadow: 0 2px 4px rgba(0,0,0,.04);
}

.navbar-brand , .nav-link, .my-form, .login-form
{
    font-family: Raleway, sans-serif;
}

.my-form
{
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
}

.my-form .row
{
    margin-left: 0;
    margin-right: 0;
}

.login-form
{
    padding-top: 1.5rem;
    padding-bottom: 1.5rem;
}

.login-form .row
{
    margin-left: 0;
    margin-right: 0;
}
</style>

<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
    <a class="navbar-brand" href="#">Job Card</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="login.php">Login</a>
            </li>
            
        </ul>

    </div>
    </div>
</nav>


		<?php $msg = "";
			if(isset($_GET['msg'])){
				$msg = "Registered Successfully";
			}
			
			if(isset($_GET['msg1'])){
				$msg = "Password do not match";
			}
		?>


<main class="my-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Register</div>
                        <div class="card-body">
                            
			 <form id="registrationForm" action="process.php" method="post">
			 
			 <div class="form-group" style="color:blue">
				<strong><label class="col-md-6"> <?php echo $msg; ?> </label></strong>
			 </div>
			
                <div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Name</label>
					<div class="col-md-6">
						<input type="text" placeholder="Name" class="form-control" name="name" id="name"  required="required">
					</div>
				</div>                 
                
                <div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Surname</label>
					<div class="col-md-6">
                    <input type="text" placeholder="Surname" class="form-control" name="surname" id="surname"  required="required">
					</div>
			   </div>                                
                
                <div class="form-group row">
                    <label for="issueBranch" class="col-md-4 col-form-label text-md-right">Branch</label>
					<div class="col-md-6">
                    <select id="branch" name="branch" class="form-control" required>
                        <option value="">Select Branch</option>
                        <option value="Polokwane">Head Office</option>
                        <option value="Pretoria">Pretoria</option>
                        <option value="Thabazimbi">Thabazimbi</option>
                        <option value="Steelport">Steelport</option>
                        <option value="Sandton">Sandton</option>
                    </select>
					</div>
                </div> 
				
				<div class="form-group row">
					<label class="col-md-4 col-form-label text-md-right">Division</label>
					<div class="col-md-6">
					<select class="form-control" id="division" name="division" required>
						<option value="">Select Division</option>
						<option value="Accounting">Accounting</option>
						<option value="ICT & Systems">ICT & Systems</option>
						<option value="Taxation">Taxation</option>
						<option value="Payroll">Payroll</option>
						<option value="Consulting">Consulting</option>
						<option value="Company Secretariat">Company Secretariat</option>
						<option value="Training & Development">Training & Development</option>
						<option value="Practice Management">Practice Management</option>
					</select>
					</div>
				</div>
                  
                
                <div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Extension</label>
					<div class="col-md-6">
						<input type="text" placeholder="Extension" class="form-control" name="offNo" id="offNo"  required="required">
					</div>
			   </div>      
                
                <div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Contact Number</label>
					<div class="col-md-6">
						<input type="text"maxlength="10" placeholder="Phone" class="form-control" name="phone" id="phone"  required="required">
					</div>
				</div>
				
				<div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Email</label>
					<div class="col-md-6">
						<input type="email" placeholder="email@xxx.com" class="form-control" name="email" id="email"  required="required">
					</div>
				</div>
				
				<div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Password</label>
					<div class="col-md-6">
						<input type="password" class="form-control" name="password" id="password"  required="required">
					</div>
				</div>
				
				<div class="form-group row">
                    <label class="col-md-4 col-form-label text-md-right">Confirm Password</label>
					<div class="col-md-6">
						<input type="password" class="form-control" name="cpassword" id="cpassword"  required="required">
					</div>
				</div>
				            
				
				<div class="col-md-6 offset-md-4">
					<button type="submit" id="regUser" name="regUser" class="btn btn-primary">Register</button><br>
				</div>
				
            </form>
							
                        </div>
                    </div>
            </div>
        </div>
    </div>

</main>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script>
  document.getElementById("registrationForm").addEventListener("submit", function (event) {
    var phoneNumber = document.getElementById("phone").value;
    var phoneError = document.getElementById("phoneError");

    // Define a regular expression for a valid phone number.
    var phonePattern = /^[0-9]{10}$/;

    if (!phonePattern.test(phoneNumber)) {
      phoneError.textContent = "Please enter a valid 10-digit phone number.";
      event.preventDefault(); // Prevent form submission
    } else {
      phoneError.textContent = ""; // Clear any previous error message
    }
  });
</script>
</body>
</html>