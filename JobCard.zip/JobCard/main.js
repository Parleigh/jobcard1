//localStorage.setItem('issues', "");

document.getElementById('issueInputForm').addEventListener('submit', saveIssue);
function saveIssue(e) {
	localStorage.clear();
 // console.log('testing');
  /*var name = document.getElementById('name').value;
  var branch = document.getElementById('branch').value;
  var division = document.getElementById('division').value;
  var offNo = document.getElementById('offNo').value;*/
  var assets = document.getElementById('assets').value;
  var description = document.getElementById('description').value;
  var severity = document.getElementById('severity').value;  
  var assignedTo = document.getElementById('assignedTo').value;
  var issueId = chance.guid();
  var issueStatus = 'Open';

  var issue = {
    id: issueId,
    //name: name,
    //branch: branch, 
    //division: division,
    //offNo: offNo, 
    assets: assets, 
    description: description,
    severity: severity,
    assignedTo: assignedTo,
    status: issueStatus
  }

  if (localStorage.getItem('issues') == null) {
    var issues = [];
    issues.push(issue);
    localStorage.setItem('issues', JSON.stringify(issues));
  } else {
    var issues = JSON.parse(localStorage.getItem('issues'));
    issues.push(issue);
    localStorage.setItem('issues', JSON.stringify(issues));
  }

 // document.getElementById('issueInputForm').reset();

  fetchIssues();
	//alert('tfrty')
  //e.preventDefault();
}

function setStatusClosed(id) {
  var issues = JSON.parse(localStorage.getItem('issues'));

  for (var i = 0; i < issues.length; i++) {
    if (issues[i].id == id) {
      issues[i].status = 'Closed';
    }
  }

  localStorage.setItem('issues', JSON.stringify(issues));

  fetchIssues();
}

function deleteIssue(id) {
	//alert(id)
  var issues = JSON.parse(localStorage.getItem('issues'));
  console.log(issues)

  for (var i = 0; i < issues.length; i++) {
    if (issues[i].id == id) {
      issues.splice(i, 1);
    }
  }

  localStorage.setItem('issues', JSON.stringify(issues));
	location.reload();
  
}

function fetchIssues() {
	
  var issues = JSON.parse(localStorage.getItem('issues'))[0];
  var issuesList = document.getElementById('issuesList');
  var i = 1;
  $("table#tableList thead tr th").each(function(){
	  if(i > 4)
		  $(this).remove()
	i++;  
  })  
  //issuesList.innerHTML = '';
		$("table#tableList thead tr").append('<th>Asset</th>'+
                                            '<th>Description</th>'+
                                            '<th>Severity</th>'+
                                            '<th>Status</th>'+
                                            '<th>Close</th>'+
                                            '<th>Delete</th>');

  											
											
		

	var row = "";

    var id = issues.id;
  /*  var name = issues.name;
	
	var surname = issues.surname;
    var branch = issues.branch;
    var division = issues.division;
    var offNo = issues.offNo;*/
    var assets = issues.assets;  
    var description = issues.description;
    var severity = issues.severity;
    var assignedTo = issues.assignedTo;
    var status = issues.status;
	var k = 1
	$("table#tableList tbody tr td").each(function(){
	  if(k > 4)
		  $(this).remove()
	k++;  
	})
	//alert(id)
					  row +='<td>'+ assets +'</td>'+
                            '<td>'+ description +'</td>'+
                            '<td>' + severity + '</td>'+
                            '<td><span class="label label-info">' + status + '</span></td>'+
                            '<td><a href="javascript:;" onclick="setStatusClosed(\''+id+'\')" class="btn btn-warning">Close</a> </td>'+
                            '<td><a href="javascript:;" onclick="deleteIssue(\''+id+'\')" class="btn btn-danger">Delete</a>';
											
							console.log(row);				

		
		
											
      /*issuesList.innerHTML +=  '<table id="example" class="table table-striped table-bordered" style="width:100%">'+
                                    '<thead>'+
                                        '<tr>'+
                                            '<th>Asset</th>'+
                                            '<th>Description</th>'+
                                            '<th>Severity</th>'+
                                            '<th>Assigned To</th>'+
                                            '<th>Status</th>'+
                                            '<th>Close</th>'+
                                            '<th>Delete</th>'+
          
                                        '</tr>'+
                                    '</thead>'+
                                    '<tbody>'+
                                        '<tr id="userRow">'+
                                            '<td>'+ assets +'</td>'+
                                            '<td>'+ description +'</td>'+
                                            '<td>' + severity + '</td>'+
                                            '<td>'+ assignedTo +'</td>'+
                                            '<td><span class="label label-info">' + status + '</span></td>'+
                                            '<td><a href="#" onclick="setStatusClosed(\''+id+'\')" class="btn btn-warning">Close</a> </td>'+
                                            '<td><a href="#" onclick="deleteIssue(\''+id+'\')" class="btn btn-danger">Delete</a>'+
                                        '</tr>'+
                                    '</tbody>'+
      
                                '</table>';*/
 
	
	console.log($("table#tableList tbody tr"))
	$("table#tableList tbody tr").append(row);
}

			$(document).ready(function(){
				//call ajax
            var ajax = new XMLHttpRequest();
            var method= "POST";
            var url = "data.php";
            var asynchronous = true;
            
            ajax.open(method, url, asynchronous);
            //sending ajax request
            ajax.send();
            
            //receiving response from data
            ajax.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    //converting JSON back to array
                    var data = JSON.parse(this.responseText); 
                    console.log(data);
                    
                    var html = "";
                    /*for (var a = 0; a < data.length; a++){
                        var name = data[a].name;
                        var surname = data[a].surname;
                        var branch = data[a].branch;
                        var division = data[a].division;
                        var offNo = data[a].offNo;*/
						
							//var phon = ["0794899923", "0783877045", "012"]; 
						
						$("table#tableList tbody").html('<tr><td>'+ data.name +' '+ data.surname +'</td>'+
																		'<td>'+ data.branch +'</td>'+
																		'<td>'+ data.division +'</td>'+
																		'<td>'+ data.offNo +'</td></tr>');
																	}
																		
                        
                    }

			});
			setTimeout(function(){fetchIssues()},500);
    /*issuesList.innerHTML += '<div class="well">'+
                              '<h6>Issue ID: ' + id + '</h6>'+
                              '<p><span class="label label-info">' + status + '</span></p>'+
                              '<h3>' + description + '</h3>'+
                              '<p><strong>Name:</strong> '+ name +'</p>' +
                              '<strong><p>Branch:</strong> '+ branch +'</p>' +
                              '<strong><p>Division:</strong> '+ division +'</p>' +
                              '<strong><p>Office Number:</strong> '+ offNo +'</p>' +
                              '<strong><p>Asset with problem:</strong> '+ assets +'</p>' +
                              '<p><span class="glyphicon glyphicon-time"></span> ' + severity + '</p>'+
                              '<p><span class="glyphicon glyphicon-user"></span> ' + assignedTo + '</p>'+
                              /* '<a href="#" onclick="setStatusClosed(\''+id+'\')" class="btn btn-warning">Close</a> '+ 
                              '<a href="#" onclick="deleteIssue(\''+id+'\')" class="btn btn-danger">Delete</a>'+
                              '</div>';*/
