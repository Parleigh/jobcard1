<?php
include('connection.php');

if(isset($_POST['chat_btn'])){
	
	$from = $_POST['from_id'];
	$to = $_POST['to_id'];
	$message = $_POST['message'];
	
	
	date_default_timezone_set('Africa/Johannesburg');
	$date =  date('Y/m/d');
	$time = date('h:i:sa');
	
	try{
		
		$sql =  "INSERT INTO chatter (fromID, ToID)
				VALUES ('$from','$to')";
				
				$sth = $conn->query($sql);
				//$lastId = mysqli_insert_id($conn);
				$lastId = $conn->lastInsertId();
				
		$sql2 = "INSERT INTO receiver (ch_id, uid, message, date, time)
				VALUES ('$lastId','$from','$message','$date','$time')";
				
				$sth2 = $conn->query($sql2);	
		
				
		header('Location: chat.php');
		exit;	
	}
	catch(PDOException $e){
		echo $e;
	}
	
}









/*$result = array();
$message = isset($_POST['message']) ? $_POST['message'] : null;
$from = $_POST['user_id'];
date_default_timezone_set('Africa/Johannesburg');
$date = $date = date('Y/m/d');
	

if(!empty($message) && !empty($from)){
	$sql = "INSERT INTO chat (u_id, chat, date)
			VALUES ('$from','$message','$date')";
	$result['send_status'] = $db->query($sql); 
}

header("Access-Control-Allow-Origin: +");
header("Content-Type: application/json");

echo json_encode($result);*/


?>