<!DOCTYPE html>
<HTML>

<style>
	
		body,
		html {
			margin: 0;
			padding: 0;
			height: 100%;
			background: #60a3bc !important;
		}
		.user_card {
			height: 400px;
			width: 350px;
			margin-top: auto;
			margin-bottom: auto;
			background: #495360;
			position: relative;
			display: flex;
			justify-content: center;
			flex-direction: column;
			padding: 10px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			-webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			-moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			border-radius: 5px;

		}
		.brand_logo_container {
			position: absolute;
			height: 170px;
			width: 170px;
			top: -75px;
			border-radius: 50%;
			background-image: url("#");
			padding: 10px;
			text-align: center;
			//background-repeat: no-repeat;
		}
		.brand_logo {
			height: 200px;
			width: 200px;
			border-radius: 50%;
			border: 2px solid white;
		}
		.form_container {
			margin-top: 50px;
		}
		.login_btn {
			width: 100%;
			background: #57b129 !important;   
			color: white !important;
		}
		.login_btn:focus {
			box-shadow: none !important;
			outline: 0px !important;
		}
		.login_container {
			padding: 0 2rem;
		}
		.input-group-text {
			background: #57b129 !important;
			color: white !important;
			border: 0 !important;
			border-radius: 0.25rem 0 0 0.25rem !important;
		}
		.input_user,
		.input_pass:focus {
			box-shadow: none !important;
			outline: 0px !important;
		}
		.custom-checkbox .custom-control-input:checked~.custom-control-label::before {
			background-color: #57b129 !important;
		}
	

</style>


    <head>
        <meta charset="utf-8">
        <title>Job Card Login</title>
        <!--compiled and miniied CSS-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        
        <link rel="stylesheet" href=" https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
		
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        
        
    </head>

    <body>

 	<?php
	


$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli("localhost",$username,$password,"jobcard_db1");

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
  }


session_start();

error_reporting(0);

if (isset($_SESSION['active']) ) {
    //header("Location: indexUser.php");
}

if (isset($_POST['login'])) {
	
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	

	$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
	$result = mysqli_query($conn, $sql);
	
	$row = mysqli_fetch_assoc($result);
	
		
		$_SESSION['id'] = $row['id'];
		$_SESSION['name'] = $row['name'];
		$_SESSION['surname'] = $row['surname'];
		$_SESSION['branch'] = $row['branch'];
		$_SESSION['division'] = $row['division'];
		$_SESSION['offNo'] = $row['offNo'];
		$_SESSION['phone'] = $row['phone'];
		$_SESSION['email'] = $row['email'];
		$_SESSION['userType'] = $row['userType'];
		$_SESSION['active'] = $row['active'];
		
		
	
	if ($result->num_rows > 0) {
		
		if($_SESSION['active'] == 1){
			
			if($_SESSION['userType'] == 1){
				header("Location: index.php");
			}
			else{
				header("Location: indexUser.php");
			}
		}
		else{
			echo "<script>alert('You need to be activated before you login')</script>";
			
		}
		
		
		
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}

}

		$msg = "";
		if(isset($_GET['msg'])){
		$msg = "Username or Password Incorrect";}
		
		$msg1 = "";
		if(isset($_GET['msg1'])){
		$msg1 = "Successfully Registered";}

?>
	
	
	


	
	<div class="container h-100">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<!--img src="" class="form-group" alt="Logo"-->
					</div>
				</div>
				<div class="d-flex justify-content-center form_container">
					

					
					<form action="" method="post">
					<div class="form-group">
							
							<!--strong><span class="form-group" style="color:red"><?php echo $msg;?> </i></span></strong>
							 <strong><span class="form-group" style="color:green"><?php echo $msg1;?> </i></span></strong-->
							
						</div>
						
						<div class="input-group mb-3">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-user"></i></span>
							</div>
							<input type="email" name="email" id="email" class="form-control input_user" value="" placeholder="username" required="required">
						</div>
						<div class="input-group mb-2">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-key"></i></span>
							</div>
							<input type="password" name="password" id="password" class="form-control input_pass" value="" placeholder="password" required="required">
						</div>
						<div class="form-group">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input" id="customControlInline">
								<label class="custom-control-label" for="customControlInline">Remember me</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<strong><a href="userReg.php">Register</a></strong>
							</div>
						</div>
							<div class="d-flex justify-content-center mt-3 login_container">
						<!--a type="submit" href="index.php" name="login" id="login" class="btn login_btn">Login</a-->
					<button class="btn login_btn d-block btn-user w-100" name="login" id="login" type="sumbit" style="background: rgb(146,74,232);" >Login</button>
				   </div>
					</form>
				</div>
		
			</div>
		</div>


		<footer>
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo date("Y") ?></span>
          </div>
        </div>
      </footer>
	  
	</div>
		
		
		
	
		
        
        
        <!--compiled and miniied JavaScript-->
        <script src="https://chancejs.com/chance.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="crossorigin="anonymous"></script>
        <!--compiled and miniied JavaScript-->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
       <!--script src="main.js"></script--> 
        
        <script src"https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src"https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src"https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
		
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		
		
        
        <!--script>
			$(document).ready(function() {
			$('#example').DataTable();
			} );
        </script-->
        
       

        
    </body>
    
</HTML>
