<?php
include("connection.php");
include("session.php");

//session_start();
// if(type != Admin){
	//header("Location:");
	//exit;
//}

//register user

if(isset($_POST['regUser'])){
	
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $branch = $_POST['branch'];
    $division = $_POST['division'];
    $offNo = $_POST['offNo'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    //$userType = $_POST['userType'];
    $password = md5($_POST['password']);
    $cpassword = md5($_POST['cpassword']);
	
	
	if ($password == $cpassword) {
		//$sql = "SELECT * FROM users WHERE email='$email'";
		//$result = mysqli_query($conn, $sql);
		
			$sql = "INSERT INTO users (name, surname, branch, division, offNo, phone, email, password, userType, active)
					VALUES ('$name', '$surname', '$branch', '$division', '$offNo', '$phone', '$email', '$password', 0, 1)";
			 $sth = $conn->query($sql); 

			header('Location: userReg.php?id='.$id.'&msg');			 
			/*if ($result) {
				echo "<script>alert('User Is Successfuly Registered') </script>";
						
				$name = "";
				$surname = "";
				$email = "";
				$branch = "";
				$division = "";
				$phone = "";
				$offNo = "";
				$userType = "";
				$_POST['password'] = "";
				$_POST['cpassword'] = "";
				
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}*/
		
		
	} else {
		//echo "<script>alert('Password Not Matched.')</script>";
		
		header('Location: userReg.php?id='.$id.'&msg1');		
	}
    
    
    /* try{
        $sql = "INSERT INTO users (name, surname, branch, division, offNo, phone, userType, active)
                VALUES ('$name','$surname','$branch','$division','$offNo','$phone', 'User',1)";
        $sth = $conn->query($sql);   
        
            header('Location: userReg.php?id='.$id.'&msg1');
			exit;
    }
    catch(PDOException $e)
    {
            echo $e;  
    } */
	
	
    
}



if(isset($_POST['register'])){
	//echo "sql";
	
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $branch = $_POST['branch'];
    $division = $_POST['division'];
    $offNo = $_POST['offNo'];
    $phone = $_POST['phone'];
    $userType = $_POST['utype'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    
    try{
        $sql = "INSERT INTO users (name, surname, branch, division, offNo, phone, email, password, userType, active)
                VALUES ('$name','$surname','$branch','$division','$offNo','$phone', '$email', '$password', '$userType',1)";
        $sth = $conn->query($sql);   
        
            header('Location: register.php?id='.$id.'&msg');
			exit;
    }
    catch(PDOException $e)
    {
            echo $e;  
    }
    
}
elseif(isset($_POST['login'])){
  
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $sql = "SELECT a.name, a.phone, a.offNo, d.division, b.branchName FROM users a, branch b, division d 
			WHERE name = '$name' AND phone = '$phone' AND a.id = b.user_id AND b.user_id = d.user_id ";
	$sql = "SELECT id, name, surname, phone, offNo, division, branch, userType, email, password, active FROM users 
			WHERE email = '$email' 
			AND password = '$password'
			AND active = 1";
			
    $sth = $conn->query($sql);  
    
    //$sth->bindParam(':phone', $phone, PDO::PARAM_STR);
    $sth->setFetchMode(PDO::FETCH_ASSOC);
	$sth->execute();
    
    $data = $sth->fetch();
    
    

    
    if($data['name']!=$name and $data['phone']!=$phone){
            header('Location: login.php?id='.$id.'&msg=');
			exit;
    }
    elseif($data['name']==$name and $data['phone']==$phone and $data['userType'] == 'Admin'){
        
        $_SESSION['name']=$data['name'];
        $_SESSION['phone']=$data['phone'];
        $_SESSION['surname']=$data['surname'];
		
		$_SESSION['id']=$data['id'];
        $_SESSION['division']=$data['division'];
        $_SESSION['branch']=$data['branch'];
        $_SESSION['offNo']=$data['offNo'];
        $_SESSION['userType']=$data['userType'];
		
		
        echo $data;
		header("location: index.php");
    }
	elseif($data['name']==$name and $data['phone']==$phone and $data['userType'] == 'User'){
		 $_SESSION['name']=$data['name'];
        $_SESSION['phone']=$data['phone'];
        $_SESSION['surname']=$data['surname'];
		
		$_SESSION['id']=$data['id'];
        $_SESSION['division']=$data['division'];
        $_SESSION['branch']=$data['branch'];
        $_SESSION['offNo']=$data['offNo'];
        $_SESSION['userType']=$data['userType'];
		
		header("location: indexUser.php");
		
	}
	
}

if(isset($_POST['addRating'])){
	
	$job_id = $_POST['job_id'];
	$issueResoved = $_POST['issueResoved_txt'];
	$resovedOnTime = $_POST['resovedOnTime_txt'];
	$rate = $_POST['rating'];
	$comments = $_POST['comments_txt'];
	$signature = $_POST['signature'];
	
	date_default_timezone_set('Africa/Johannesburg');
	$dte = date("Y-m-d H:i:s");
	$Date = date("Y/m/d");
	$Time = date("h:i:sa");
	
	try{
	$sql = "INSERT INTO rate(issue_id, issueResoved, resovedOnTime, rate , comments, signature, date)
			VALUES ('$job_id','$issueResoved','$resovedOnTime', '$rate','$comments','$signature','$dte')";
			$sth = $conn->query($sql);
			
			$sql2 = "UPDATE status SET status = 'Closed', dater = '$Date', timer = '$Time'
					 WHERE job_id = '$job_id'"; 
			$sth = $conn->query($sql2);
				
			$sql3 = "UPDATE status2 SET status = 'Closed', dt = NOW()
					 WHERE job_id = '$job_id'";	
			$sth = $conn->query($sql3);		 
				
				header('Location: reportUser.php');
	}
	catch(PDOException $e){
		echo $e;
	}	
}


/*if(isset($_GET['login'])){
	
	$user = $_GET['name'];
	$phone = $_GET['phone'];
	
	$sql = "SELECT name, phone FROM users WHERE name = '$user' AND phone = '$phone'";
    $sth = $conn->query($sql);
	$stmt = $conn->prepare($sql);
	$stmt->bindParam(':name', $user, PDO::PARAM_STR);
	$stmt->execute();
	$total = $stmt->rowCount();
	echo $total;
	if ($total > 0){
        //echo "sss";
        //session_start();
        //$_SESSION['name'] = $name;
		header("Location: index.html"); * Redirect browser *
		exit();
	}
    else { 
            echo "incorrect";
            echo "<script>alert('Incorrect Email or Password');
            window.location.href = 'login.html'
            </script>";
         }
}

if(isset($_POST['login'])){
    
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    
    try{
    $sql = "INSERT INTO name, phone
            VALUES '$name','$phone'";
    $sth = $conn->query($sql);
        echo "Success";
    }
    catch(PDOException $e)
    {
        echo "NoSuccess";
    }
}*/


//update users
if (isset($_POST['update_btn'])){
	
	$id = $_POST['id_edt'];
	$name = $_POST['name_edt'];
	$surname = $_POST['surname_edt'];
	$offNo = $_POST['offNo_edt'];
	$division = $_POST['division_edt'];
	$branch = $_POST['branch_edt'];
	$phone = $_POST['phone_edt'];
	$userType = $_POST['user_edt'];
	$active = $_POST['active'];
	
	
	
	try{
		$sql = "UPDATE users
				SET name = '$name', surname = '$surname', offNo = '$offNo', division = '$division', branch = '$branch', phone = '$phone', 
					userType = '$userType', active = '$active'	
					WHERE id = $id";	
		$sth = $conn->query($sql);
		
			header('Location: users.php?id='.$id.'&msg=');
			exit;
	}
	catch(PDOException $e){
		echo "<script>alert('Not Updated, Speak to the coder');
            window.location.href = 'users.php'
            </script>";
	}
			
}


if(isset($_POST['delete_btn'])){
	
	$id = $_POST['dlt_id'];
	
	
	try{
		$sql = "UPDATE users SET active = 0
				WHERE id = '$id'";	
		$sth = $conn->query($sql);
		
            header('Location: users.php?id='.$id.'&msg2=');
			exit;
	}
	catch(PDOException $e){
		echo "<script>alert('Not Removed, cantact the Developer');
            window.location.href = 'users.php'
            </script>";
	}
	
	
}




if(isset($_POST['btn_status'])){
	
	
	$id = $_POST['job_ID'];
	$status = $_POST['status'];
	$desc = $_POST['comments'];
	$escalatedTo = $_POST['stat'];
	$user = $_POST['user'];
	$it_guy = $_POST['nams'];
	$company1 = $_POST['other'];
	
	//for hidden txtboxes
	/*if($_POST['other']){
		$escalatedTo = $_POST['other'];
	}*/
	
	date_default_timezone_set('Africa/Johannesburg');
	$date = date('Y/m/d');
	$time = date('h:i:sa');
	
	
	$d = date('Y/m/d');
	$t = date('h:i:sa');
	
	//$company = $_POST['stat'];
	//$other = $_POST['other'];
	
	try{
		$sql = "UPDATE status 
				SET job_id = '$id', user_id = '$user', it_guy = '$it_guy', status = '$status', 
				comments = '$desc', escalatedTo = '$escalatedTo', dater = '$date', timer = '$time'
				WHERE job_id = '$id'";
				echo $sql;
			$sth = $conn->query($sql);
			
			$sql1 = "UPDATE status SET dater = NOW()
					WHERE job_id = '$id'";
					echo $sql1;
				
			$sth = $conn->query($sql1);
			
			
			if($status == "Escalated"){
				
					//$company = $other;
					
					$sql3 = "INSERT INTO companies(job_id, company) VALUES ('$id', '$company1')";
					$sth = $conn->query($sql3);
				
			}else{
				//$sql4 = "INSERT INTO companies(job_id, company) VALUES ('$id', 'None')";
				//	$sth = $conn->query($sql4);
			}
			
			//new code
			$sql2 = "INSERT INTO status2 (job_id, user_id, it_guy, status, comments, dt)
				VALUES ('$id', '$user', '$it_guy', '$status', '$desc', NOW())";
				echo $sql2;
			$sth = $conn->query($sql2);
			
			
			
		header('Location: report_status.php?id='.$id.'&msg=');
		exit;
			//echo "<script>alert('Successfully Updated Status');
           // window.location.href = 'report_status.php?id=$id'
           // </script>";
	}
	catch(PDOException $e){
		echo $e;
	
		
		}
}
















?>