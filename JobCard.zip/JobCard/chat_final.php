<?php 
include('connection.php');
include('session.php');
//include('data.php');

if(empty($_SESSION['name'])){
    header('location: login.php');
}
    

    //$userDetails=$userClass->userDetails($session_id);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Job Card - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <!--link href="css/sb-admin-2.min.css" rel="stylesheet"-->

  <link rel="stylesheet" type="text/css" href="css/chat.css">

</head>


 <!--style>	
		
		/* Chat containers */
.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

/* Darker chat container */
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

/* Clear floats */
.container::after {
  content: "";
  clear: both;
  display: table;
}

/* Style images */
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

/* Style the right image */
.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

/* Style time text */
.time-right {
  float: right;
  color: #aaa;
}

/* Style time text */
.time-left {
  float: left;
  color: #999;
}
		
</style-->

<body>

	<div class="container main-selection">
		<div class="row">
			<div class="col-md-3 col-sm-3 col-xs-3 left-sidebar">
				<div class="input-group searchbox">
					<div class="input-group-btn">
						<center><a href="#"><button class="btn btn-default search-icon" name="search"></button></a></center>
					</div>
				</div>
				<div class="left-chat">
					<ul>
						<?php include("chat_getUsers.php") ?>
					</ul>
				</div>
			</div>
			
			<div class="col-md-9 col-sm-9 col-xs-12 right-sidebar">
				<div class="row">
					<?php 
						$servername = "localhost";
						$username = "root";
						$password = "";
						$dbname = "jobcard_db";

						// Create connection
						$conn = mysqli_connect($servername, $username, $password, $dbname);
						
						// Check connection
						if (!$conn) {
							die("Connection failed: " . mysqli_connect_error());
						}
					
					
					
						$user = $_SESSION['name'];
						$get_user = "SELECT * FROM users
									WHERE name = '$user'";
						$r_user = mysqli_query($conn, $get_user);
						$row = mysqli_fetch_array($r_user);
						
						$user_id = $row['id'];	
						$user_name = $row['name'];	
					?>
					
					<?php
						//getting data which user clicks
						if(isset($_GET['name'])){
							
							global $conn;
							
							$get_name = $_GET['name'];
							$get_user = "SELECT * FROM users WHERE name = '$get_name'";
							$r_user = mysqli_query($conn, $get_user);
							$row = mysqli_fetch_array($r_user);
							
							$userName = $row['name'];
							echo "hhg";
						} 
						
						$total_msg = "SELECT * FROM users_chat 
									WHERE (sender = '$user_name' AND receiver = '$userName')
									OR (receiver = '$user_name' AND sender = '$userName')";
								
								$run_msg = mysqli_query($conn, $total_msg);
								$total = mysqli_num_rows($run_msg);		
					?>	
					
					<div class="col-md-12 right-header">
						<div class="right-header-detail">
							<form method="post">
								<p> <?php echo $userName ?> </p>
								<span> <?php echo $total; ?> messages </span> &nbsp &nbsp
								<button class="btn btn-danger" name="logout">Logout</button>
							</form>
							<?php
								if(isset($_POST['logout'])){
									$update_msg = mysqli_query($conn, "UPDATE users SET log_in = 'Offline'
													WHERE name = '$user_name'");
									header("Location:logout.php");
									exit();
								}
							?>
							
						</div>
					
					</div>

				</div>
				
				<div class="row">
					<div id="scrolling_to_bottom" class="col-md-12 right-header-contentChat">
						<?php 
							$update_msg = mysqli_query($conn, "UPDATE users_chat SET msg_status = 'read'
								WHERE sender = '$userName' AND receiver = '$user_name'");
								
							$sel_msg = "SELECT * FROM users_chat
								WHERE (sender = '$user_name' AND receiver = '$userName')
								OR (sender = '$userName' AND receiver = '$user_name')
								ORDER BY 1 ASC";

							$r_msg = mysqli_query($conn, $sel_msg);
							
							while($row = mysqli_fetch_array($r_msg)){
								
								$sender = $row['sender'];
								$receiver = $row['receiver'];
								$msg = $row['msg_content'];
								$date = $row['msg_date'];
								
						?>
						
						<ul>
							<?php 
								if($user_name == $sender AND $userName == $receiver){
									echo "
										<li>
											<div >
												<span> $userName <small>$date</small></span>
												<p>$msg</p>
											</div>
										</li>
									";
								}
								
								if($user_name == $receiver AND $userName == $sender){
									echo "
										<li>
											<div>
												<span> $userName <small>$date</small></span>
												<p>$msg</p>
											</div>
										</li>
									";
								}
							?>
						</ul>
						<?php
							}
						?>
						
					</div>
				</div>
				
				<div clas="row">
					<div class="col-md-12 right-chat-textbox">
						<form method="post">
							<input autocomplete="off" type="text" name="msg_content" placeholder="type..">
							<button class="btn" name="submit"><i class="fa fa-telegram" aria-hidden="true"</i>
							</button>
						</form>
					</div>
				</div>
				
			</div>
			
		</div>
	
	</div>
  
	<?php
		if(isset($_POST['submit'])){
			$msg = htmlentities($_POST['msg_content']);
			
			if($msg == ""){
			echo "
				<div >
					<strong><center> Message was unable to send </center></strong>
				</div>
				"; 
			}
			else if(strlen($msg) > 200){
			echo "
				<div >
					<strong><center> Message too long, use less than 200 characters </center></strong>
				</div>
				"; 
			}
			else{
				$insert = "INSERT INTO users_chat(sender, receiver, msg_content, msg_status, msg_date)
							VALUES ('$user_name','$userName','$msg','unread', NOW())";
				$r_insert = mysqli_query($conn, $insert);			
			}
		}
	?>
  
  
  
  
  
  
  
  
  
  

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  
   <script>
	function Rowonclick(id) {
		//alert(id)
	
		location.href = "report_status.php?id="+id;
		
  }
  </script>
  
   <script>
		$(document).ready(function() {
		$('#example').DataTable();
		} );
	</script>
	
	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
	
		
	<script>
	function exportTableToExcel(example, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(example);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'Outstanding_report.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
</script>	
	
</body>			
			
</html>			
			
			